# Admin-Dashboard
simple admin dash board using laravel


# after download run this command
- composer update
- php artisan migrate --seed
- php artisan serve
