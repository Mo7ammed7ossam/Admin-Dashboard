<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Campaigns')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 ">
        <div class=" mx-auto sm:px-6 lg:px-8">
            <div class="flex flex-col">
                <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div class="py-4 inline-block w-full sm:px-6 lg:px-8">
                        <div class="overflow-hidden">
                            <table class="w-full text-center">
                                <thead class="border-b bg-gray-800">
                                    <tr>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">

                                        </th>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                            SingUp
                                        </th>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                            Massage Therapy
                                        </th>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                            Chiropractic Care
                                        </th>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                            Yoga Exercise
                                        </th>
                                        <th scope="col" class="text-sm font-medium text-white px-6 py-4">
                                            Other
                                        </th>
                                    </tr>
                                </thead class="border-b">
                                <tbody>
                                    <tr class="bg-white border-b">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Total
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <?php echo e($users); ?>

                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            ( <?php echo e($options->massage_therapy); ?> ) Votes
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            ( <?php echo e($options->chiropractic_care); ?> ) Votes
                                        </td>

                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            ( <?php echo e($options->yoga_exercise); ?> ) Votes
                                        </td>

                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            ( <?php echo e($options->others); ?> ) Votes
                                        </td>
                                    </tr class="bg-white border-b">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\Users\wiko\Desktop\arun\Admin-Dashboard\Back-End\resources\views/admin/index.blade.php ENDPATH**/ ?>